
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'dart:async';
import 'dart:math';

// ===== MOCK DATA MODELS (No database required) =====
class BinSensor {
  final int id;
  final String location;
  final double lat;
  final double lng;
  double fillLevel;
  DateTime lastUpdated;
  String status;

  BinSensor({
    required this.id,
    required this.location,
    required this.lat,
    required this.lng,
    required this.fillLevel,
    required this.lastUpdated,
    required this.status,
  });

  Color get statusColor {
    switch (status) {
      case 'critical': return Colors.red;
      case 'moderate': return Colors.orange;
      case 'low': return Colors.green;
      default: return Colors.grey;
    }
  }

  void updateFillLevel(double newLevel) {
    fillLevel = newLevel.clamp(0.0, 1.0);
    lastUpdated = DateTime.now();
    status = fillLevel > 0.7 ? 'critical' : fillLevel > 0.3 ? 'moderate' : 'low';
  }
}

class CollectionSchedule {
  final int id;
  final String day;
  final String wasteType;
  final String time;
  final String location;
  final bool isActive;

  CollectionSchedule({
    required this.id,
    required this.day,
    required this.wasteType,
    required this.time,
    required this.location,
    this.isActive = true,
  });

  Color get typeColor {
    switch (wasteType.toLowerCase()) {
      case 'biodegradable': return Colors.brown;
      case 'non-biodegradable': return Colors.black54;
      case 'recyclables': return Colors.blue;
      default: return Colors.grey;
    }
  }
}

class ReportIssue {
  final int id;
  final String location;
  final String issueType;
  final String description;
  final DateTime timestamp;
  final String? imagePath;
  String status;

  ReportIssue({
    required this.id,
    required this.location,
    required this.issueType,
    required this.description,
    required this.timestamp,
    this.imagePath,
    this.status = 'pending',
  });

  Color get statusColor {
    switch (status) {
      case 'pending': return Colors.orange;
      case 'in_progress': return Colors.blue;
      case 'resolved': return Colors.green;
      default: return Colors.grey;
    }
  }
}

// ===== MOCK DATA SERVICE (In-memory storage) =====
class MockDataService {
  static final MockDataService _instance = MockDataService._internal();
  factory MockDataService() => _instance;
  MockDataService._internal();
  
List<BinSensor> _binSensors = [
  BinSensor(
    id: 1,
    location: 'Katipunan Ave (North)',
    lat: 14.6405,
    lng: 121.0745,
    fillLevel: 0.85,
    lastUpdated: DateTime.now(),
    status: 'critical',
  ),
  BinSensor(
    id: 2,
    location: 'Ateneo Gate 2',
    lat: 14.6390,
    lng: 121.0750,
    fillLevel: 0.40,
    lastUpdated: DateTime.now(),
    status: 'moderate',
  ),
  BinSensor(
    id: 3,
    location: 'UP Town Center',
    lat: 14.6507,
    lng: 121.0742,
    fillLevel: 0.65,
    lastUpdated: DateTime.now(),
    status: 'moderate',
  ),
  BinSensor(
    id: 4,
    location: 'Miriam College',
    lat: 14.6385,
    lng: 121.0725,
    fillLevel: 0.20,
    lastUpdated: DateTime.now(),
    status: 'low',
  ),
  BinSensor(
    id: 5,
    location: 'Loyola Heights Barangay Hall',
    lat: 14.6420,
    lng: 121.0730,
    fillLevel: 0.75,
    lastUpdated: DateTime.now(),
    status: 'critical',
  ),
  BinSensor(
    id: 6,
    location: 'Katipunan Flyover',
    lat: 14.6450,
    lng: 121.0755,
    fillLevel: 0.30,
    lastUpdated: DateTime.now(),
    status: 'low',
  ),
  BinSensor(
    id: 7,
    location: 'Jeepney Terminal',
    lat: 14.6415,
    lng: 121.0740,
    fillLevel: 0.90,
    lastUpdated: DateTime.now(),
    status: 'critical',
  ),
  BinSensor(
    id: 8,
    location: 'Residential Area',
    lat: 14.6435,
    lng: 121.0720,
    fillLevel: 0.50,
    lastUpdated: DateTime.now(),
    status: 'moderate',
  ),
];

  List<CollectionSchedule> _schedules = [
    CollectionSchedule(id: 1, day: 'Monday', wasteType: 'Biodegradable', time: '6:00 AM', location: 'All Areas'),
    CollectionSchedule(id: 2, day: 'Wednesday', wasteType: 'Non-Biodegradable', time: '7:00 AM', location: 'All Areas'),
    CollectionSchedule(id: 3, day: 'Friday', wasteType: 'Recyclables', time: '6:30 AM', location: 'All Areas'),
    CollectionSchedule(id: 4, day: 'Saturday', wasteType: 'Biodegradable', time: '7:30 AM', location: 'Coastal Areas Only'),
  ];

  List<ReportIssue> _reports = [];
  int _nextReportId = 1;
  final Random _random = Random();

  void simulateBinUpdates() {
    for (var bin in _binSensors) {
      double randomChange = (_random.nextDouble() - 0.5) * 0.2;
      bin.updateFillLevel(bin.fillLevel + randomChange);
    }
  }

  List<BinSensor> getBinSensors() => List.from(_binSensors);
  
  List<CollectionSchedule> getSchedules({String? query}) {
    if (query == null || query.isEmpty) return List.from(_schedules);
    return _schedules.where((s) => 
      s.location.toLowerCase().contains(query.toLowerCase()) ||
      s.wasteType.toLowerCase().contains(query.toLowerCase()) ||
      s.day.toLowerCase().contains(query.toLowerCase())
    ).toList();
  }
  
  void addBinSensor(String location, double fillLevel) {
 _binSensors.add(BinSensor(
  id: _binSensors.length + 1,
  location: location,
  lat: 14.6000 + Random().nextDouble() * 0.01, // 👈 ADD
  lng: 120.9800 + Random().nextDouble() * 0.01, // 👈 ADD
  fillLevel: fillLevel,
  lastUpdated: DateTime.now(),
  status: fillLevel > 0.7 ? 'critical' : fillLevel > 0.3 ? 'moderate' : 'low',
));
  }
  
  void submitReport(String location, String issueType, String description) {
    _reports.insert(0, ReportIssue(
      id: _nextReportId++,
      location: location,
      issueType: issueType,
      description: description,
      timestamp: DateTime.now(),
      imagePath: _random.nextBool() ? 'mock_image' : null,
    ));
    
    if (_reports.length > 5 && _reports.last.status == 'pending') {
      _reports.last.status = 'resolved';
    }
  }
  
  List<ReportIssue> getReports() => List.from(_reports);
}

class Truck {
  double lat;
  double lng;

  Truck({required this.lat, required this.lng});

  void move() {
    lat += (Random().nextDouble() - 0.5) * 0.001;
    lng += (Random().nextDouble() - 0.5) * 0.001;
  }
}

void main() {
  runApp(const WasteWatchApp());
}

class WasteWatchApp extends StatelessWidget {
  const WasteWatchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WasteWatch PH',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1B5E20),
          primary: const Color(0xFF2E7D32),
        ),
        // FIXED: Changed CardTheme → CardThemeData (critical fix for DartPad)
        cardTheme: CardThemeData(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  final MockDataService _dataService = MockDataService();
  List<BinSensor> _binSensors = [];
  List<CollectionSchedule> _schedules = [];
  // FIXED: Timer is now recognized with dart:async import
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _loadData();
    // FIXED: Timer.periodic now works with proper import
    _refreshTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      _dataService.simulateBinUpdates();
      _loadData();
    });
  }

  void _loadData() {
    setState(() {
      _binSensors = _dataService.getBinSensors();
      _schedules = _dataService.getSchedules();
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: [
          DashboardView(
            binSensors: _binSensors, 
            onRefresh: _loadData,
            onAddBin: (location, level) {
              _dataService.addBinSensor(location, level);
              _loadData();
            },
          ),
          ScheduleView(
            schedules: _schedules, 
            onSearch: (query) => setState(() {
              _schedules = _dataService.getSchedules(query: query);
            }),
          ),
          ReportView(
            onNewReport: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ReportForm(onSubmit: (loc, type, desc) {
                _dataService.submitReport(loc, type, desc);
                if (mounted) Navigator.pop(context);
              })),
            ),
            reports: _dataService.getReports(),
          ),
          
          MapView(bins: _binSensors),
        ],
        
      ),
      
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) => setState(() => _currentIndex = index),
        destinations: const [
  NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Status'),
  NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'Schedule'),
  NavigationDestination(icon: Icon(Icons.report_problem_outlined), label: 'Report'),
  NavigationDestination(icon: Icon(Icons.map_outlined), label: 'Map'), // 👈 ADD
],
      ),
      floatingActionButton: _currentIndex == 2
        ? FloatingActionButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ReportForm(onSubmit: (loc, type, desc) {
                _dataService.submitReport(loc, type, desc);
                if (mounted) Navigator.pop(context);
              })),
            ),
            backgroundColor: const Color(0xFF2E7D32),
            child: const Icon(Icons.add_alert),
          )
        : null,
    );
  }
}

// ===== DASHBOARD VIEW =====
class DashboardView extends StatelessWidget {
  final List<BinSensor> binSensors;
  final VoidCallback onRefresh;
  final Function(String, double) onAddBin;

  const DashboardView({
    super.key,
    required this.binSensors,
    required this.onRefresh,
    required this.onAddBin,
  });

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async {
        onRefresh();
        return Future.delayed(const Duration(milliseconds: 500));
      },
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          SliverAppBar.large(
            title: const Text("WasteWatch", style: TextStyle(fontWeight: FontWeight.bold)),
            actions: [
              IconButton(icon: const Icon(Icons.refresh), onPressed: onRefresh),
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: Badge(
                  label: Text('${binSensors.where((b) => b.status == "critical").length}'), 
                  child: const Icon(Icons.notifications_active)
                ),
              )
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildLiveTruckCard(),
                  const SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("Neighborhood Bin Fill Levels", 
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      TextButton.icon(
                        onPressed: () => _showAddBinDialog(context),
                        icon: const Icon(Icons.add, size: 16),
                        label: const Text('Add Bin', style: TextStyle(fontSize: 14)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ...binSensors.map((bin) => _buildBinSensorTile(context, bin)),
                  if (binSensors.isEmpty) _buildEmptyState('No bins registered yet'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLiveTruckCard() => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFF2E7D32), Color(0xFF1B5E20)]),
      borderRadius: BorderRadius.circular(20),
      boxShadow: [BoxShadow(color: Colors.green.withOpacity(0.3), blurRadius: 10)],
    ),
    child: const Row(
      children: [
        CircleAvatar(
          backgroundColor: Colors.white24, 
          radius: 30,
          child: Icon(Icons.local_shipping, color: Colors.white, size: 30)
        ),
        SizedBox(width: 16),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Truck Incoming", style: TextStyle(color: Colors.white70, fontSize: 14)),
            Text("ETA: 8 Minutes", style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            Text("Currently at: Rizal Avenue", style: TextStyle(color: Colors.white54, fontSize: 12)),
          ],
        )),
        Icon(Icons.arrow_forward_ios, color: Colors.white70),
      ],
    ),
  );

  Widget _buildBinSensorTile(BuildContext context, BinSensor bin) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Flexible(
                child: Text(
                  bin.location, 
                  style: const TextStyle(fontWeight: FontWeight.w500), 
                  overflow: TextOverflow.ellipsis
                )
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: bin.statusColor.withOpacity(0.15), 
                  borderRadius: BorderRadius.circular(12)
                ),
                child: Text(
                  "${(bin.fillLevel * 100).toInt()}%", 
                  style: TextStyle(
                    color: bin.statusColor, 
                    fontWeight: FontWeight.bold, 
                    fontSize: 16
                  )
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: bin.fillLevel,
              minHeight: 10,
              backgroundColor: Colors.grey.shade200,
              valueColor: AlwaysStoppedAnimation<Color>(bin.statusColor),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Last updated: ${_formatTimeAgo(bin.lastUpdated)}", 
                style: TextStyle(color: Colors.grey.shade600, fontSize: 12)
              ),
              IconButton(
                icon: const Icon(Icons.info_outline, size: 18),
                onPressed: () => _showBinDetails(context, bin),
              ),
            ],
          ),
        ],
      ),
    ),
  );

  void _showBinDetails(BuildContext context, BinSensor bin) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Bin Details'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _detailRow('Location', bin.location),
            _detailRow('Current Fill Level', '${(bin.fillLevel * 100).toInt()}%'),
            _detailRow('Status', _statusText(bin.status), color: bin.statusColor),
            _detailRow('Last Updated', _formatDateTime(bin.lastUpdated)),
            const SizedBox(height: 16),
            const Text('Recommendation:', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(_getRecommendation(bin.fillLevel), style: TextStyle(color: Colors.blue.shade700)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context), 
            child: const Text('CLOSE')
          )
        ],
      ),
    );
  }

  Widget _detailRow(String label, String value, {Color? color}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 100, 
          child: Text('$label:', style: const TextStyle(fontWeight: FontWeight.bold))
        ),
        Expanded(
          child: Text(
            value, 
            style: TextStyle(color: color ?? Colors.black87), 
            overflow: TextOverflow.ellipsis
          )
        ),
      ],
    ),
  );

  String _statusText(String status) {
    switch (status) {
      case 'critical': return 'CRITICAL - Needs immediate collection';
      case 'moderate': return 'MODERATE - Schedule collection soon';
      case 'low': return 'LOW - Normal status';
      default: return 'UNKNOWN';
    }
  }

  String _formatDateTime(DateTime dateTime) {
    return '${dateTime.day}/${dateTime.month} ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
  }

  String _getRecommendation(double fillLevel) {
    if (fillLevel > 0.7) return 'URGENT: Schedule collection within 2 hours';
    if (fillLevel > 0.4) return 'Schedule collection within 24 hours';
    return 'Normal monitoring required';
  }

  String _formatTimeAgo(DateTime dateTime) {
    final difference = DateTime.now().difference(dateTime);
    if (difference.inMinutes < 1) return 'Just now';
    if (difference.inMinutes < 60) return '${difference.inMinutes}m ago';
    if (difference.inHours < 24) return '${difference.inHours}h ago';
    return '${difference.inDays}d ago';
  }

  void _showAddBinDialog(BuildContext context) {
    final locationController = TextEditingController();
    double fillLevel = 0.5;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('Add New Bin Sensor'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: locationController,
                decoration: const InputDecoration(
                  labelText: 'Bin Location',
                  hintText: 'e.g., Brgy. San Isidro Park',
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  const Text('Fill Level: '),
                  Expanded(
                    child: Slider(
                      value: fillLevel,
                      min: 0,
                      max: 1,
                      divisions: 20,
                      onChanged: (value) => setState(() => fillLevel = value),
                    ),
                  ),
                  Text('${(fillLevel * 100).toInt()}%'),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context), 
              child: const Text('CANCEL')
            ),
            ElevatedButton(
              onPressed: () {
                if (locationController.text.isNotEmpty) {
                  onAddBin(locationController.text, fillLevel);
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Bin sensor added successfully!')),
                  );
                }
              },
              child: const Text('ADD BIN'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(String message) => Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        children: [
          Icon(Icons.inbox, size: 48, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Text(message, style: TextStyle(color: Colors.grey.shade600)),
        ],
      ),
    ),
  );
}

// ===== SCHEDULE VIEW =====
class ScheduleView extends StatefulWidget {
  final List<CollectionSchedule> schedules;
  final Function(String) onSearch;

  const ScheduleView({
    super.key,
    required this.schedules,
    required this.onSearch,
  });

  @override
  State<ScheduleView> createState() => _ScheduleViewState();
}

class _ScheduleViewState extends State<ScheduleView> {
  final TextEditingController _searchController = TextEditingController();
  List<CollectionSchedule> _filteredSchedules = [];

  @override
  void initState() {
    super.initState();
    _filteredSchedules = widget.schedules;
    _searchController.addListener(() {
      widget.onSearch(_searchController.text);
      setState(() {
        _filteredSchedules = widget.schedules.where((schedule) =>
          schedule.location.toLowerCase().contains(_searchController.text.toLowerCase()) ||
          schedule.wasteType.toLowerCase().contains(_searchController.text.toLowerCase()) ||
          schedule.day.toLowerCase().contains(_searchController.text.toLowerCase())
        ).toList();
      });
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Collection Schedule"),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list), 
            onPressed: _showFilterDialog
          )
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: "Search by location, type, or day...",
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear), 
                      onPressed: () => _searchController.clear()
                    )
                  : null,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                filled: true,
                fillColor: Colors.grey.shade50,
              ),
            ),
          ),
          Expanded(
            child: _filteredSchedules.isEmpty
              ? _buildEmptyState('No schedules found for your search')
              : ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _filteredSchedules.length,
                  separatorBuilder: (context, index) => const SizedBox(height: 8),
                  itemBuilder: (context, index) => _buildScheduleCard(_filteredSchedules[index]),
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildScheduleCard(CollectionSchedule schedule) => Card(
    child: ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: schedule.typeColor.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(Icons.restore_from_trash, color: schedule.typeColor),
      ),
      title: Text(
        schedule.day, 
        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 4),
          Text(schedule.wasteType),
          Text(
            'Location: ${schedule.location}', 
            style: TextStyle(color: Colors.grey.shade700, fontSize: 12)
          ),
        ],
      ),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              schedule.time, 
              style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF2E7D32))
            ),
          ),
          const SizedBox(height: 4),
          Text(
            _getNextCollectionDate(schedule.day), 
            style: TextStyle(fontSize: 11, color: Colors.grey.shade600)
          ),
        ],
      ),
      isThreeLine: true,
    ),
  );

  String _getNextCollectionDate(String day) {
    final days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    final todayIndex = DateTime.now().weekday - 1;
    final targetIndex = days.indexOf(day);
    int daysUntil = targetIndex - todayIndex;
    if (daysUntil <= 0) daysUntil += 7;
    final nextDate = DateTime.now().add(Duration(days: daysUntil));
    return '${nextDate.day}/${nextDate.month}';
  }

  void _showFilterDialog() {
    bool showBio = true, showNonBio = true, showRecyclables = true;
    
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('Filter Schedules'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CheckboxListTile(
                title: const Text('Biodegradable'),
                value: showBio,
                onChanged: (v) => setState(() => showBio = v!),
                controlAffinity: ListTileControlAffinity.leading,
              ),
              CheckboxListTile(
                title: const Text('Non-Biodegradable'),
                value: showNonBio,
                onChanged: (v) => setState(() => showNonBio = v!),
                controlAffinity: ListTileControlAffinity.leading,
              ),
              CheckboxListTile(
                title: const Text('Recyclables'),
                value: showRecyclables,
                onChanged: (v) => setState(() => showRecyclables = v!),
                controlAffinity: ListTileControlAffinity.leading,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context), 
              child: const Text('CANCEL')
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _filteredSchedules = widget.schedules.where((s) {
                    if (s.wasteType == 'Biodegradable') return showBio;
                    if (s.wasteType == 'Non-Biodegradable') return showNonBio;
                    if (s.wasteType == 'Recyclables') return showRecyclables;
                    return true;
                  }).toList();
                });
                Navigator.pop(context);
              },
              child: const Text('APPLY'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(String message) => Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        children: [
          Icon(Icons.schedule, size: 48, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Text(message, style: TextStyle(color: Colors.grey.shade600)),
        ],
      ),
    ),
  );
}

// ===== REPORT VIEW =====
class ReportView extends StatelessWidget {
  final VoidCallback onNewReport;
  final List<ReportIssue> reports;

  const ReportView({
    super.key,
    required this.onNewReport,
    required this.reports,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Report Issue")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(Icons.feedback_outlined, size: 60, color: Colors.grey),
            const SizedBox(height: 16),
            const Text(
              "Help us improve service in your community", 
              textAlign: TextAlign.center, 
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500)
            ),
            const Text(
              "Report missed collections, overflowing bins, or other concerns",
              textAlign: TextAlign.center, 
              style: TextStyle(color: Colors.grey)
            ),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: onNewReport,
              icon: const Icon(Icons.add_circle_outline),
              label: const Text('CREATE NEW REPORT'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2E7D32),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 32),
            if (reports.isEmpty) ...[
              _buildEmptyState('No reports submitted yet', 'Tap "CREATE NEW REPORT" to get started'),
            ] else ...[
              const Row(
                children: [
                  Text(
                    'Your Reports', 
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)
                  ),
                  Spacer(),
                  Icon(Icons.refresh, size: 18, color: Colors.grey),
                  SizedBox(width: 4),
                  Text(
                    'Auto-refreshes', 
                    style: TextStyle(color: Colors.grey, fontSize: 12)
                  ),
                ],
              ),
              const SizedBox(height: 16),
              ...reports.map((report) => _buildReportCard(report)),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildReportCard(ReportIssue report) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                report.issueType, 
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: report.statusColor,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  report.status.toUpperCase(), 
                  style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(report.location, style: TextStyle(color: Colors.grey.shade700)),
          const SizedBox(height: 12),
          Text(report.description, maxLines: 2, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 12),
          Row(
            children: [
              const Icon(Icons.access_time, size: 16, color: Colors.grey),
              const SizedBox(width: 4),
              Text(
                _formatReportTime(report.timestamp), 
                style: TextStyle(color: Colors.grey.shade600, fontSize: 12)
              ),
            ],
          ),
          if (report.imagePath != null) ...[
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Container(
                height: 100,
                color: Colors.grey.shade200,
                child: const Center(
                  child: Text(
                    '📸 Photo Attached (Simulated)', 
                    style: TextStyle(color: Colors.grey)
                  )
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(onPressed: () {}, child: const Text('VIEW DETAILS')),
            ],
          ),
        ],
      ),
    ),
  );

  String _formatReportTime(DateTime timestamp) {
    final difference = DateTime.now().difference(timestamp);
    if (difference.inMinutes < 1) return 'Just now';
    if (difference.inMinutes < 60) return '${difference.inMinutes} minutes ago';
    if (difference.inHours < 24) return '${difference.inHours} hours ago';
    return '${difference.inDays} days ago';
  }

  Widget _buildEmptyState(String title, String subtitle) => Padding(
    padding: const EdgeInsets.all(32),
    child: Column(
      children: [
        Icon(Icons.inbox, size: 48, color: Colors.grey.shade400),
        const SizedBox(height: 16),
        Text(title, style: TextStyle(color: Colors.grey.shade700)),
        Text(subtitle, style: TextStyle(color: Colors.grey.shade500)),
      ],
    ),
  );
}

// ===== REPORT FORM =====
class ReportForm extends StatefulWidget {
  final Function(String, String, String) onSubmit;

  const ReportForm({super.key, required this.onSubmit});

  @override
  State<ReportForm> createState() => _ReportFormState();
}

class _ReportFormState extends State<ReportForm> {
  final _formKey = GlobalKey<FormState>();
  final _locationController = TextEditingController();
  final _descriptionController = TextEditingController();
  String _selectedIssueType = 'Missed Collection';
  bool _isSubmitting = false;

  final List<String> _issueTypes = [
    'Missed Collection',
    'Overflowing Bin',
    'Damaged Bin',
    'Illegal Dumping',
    'Other'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("New Report")),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Location', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              TextFormField(
                controller: _locationController,
                decoration: const InputDecoration(
                  hintText: 'Barangay, Street, or Landmark',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value?.isEmpty ?? true ? 'Please enter a location' : null,
              ),
              const SizedBox(height: 24),
              
              const Text('Issue Type', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: _selectedIssueType,
                decoration: const InputDecoration(border: OutlineInputBorder()),
                items: _issueTypes.map((type) => DropdownMenuItem(value: type, child: Text(type))).toList(),
                onChanged: (value) => setState(() => _selectedIssueType = value!),
              ),
              const SizedBox(height: 24),
              
              const Text('Description', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              TextFormField(
                controller: _descriptionController,
                maxLines: 4,
                decoration: const InputDecoration(
                  hintText: 'Provide details about the issue...',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value?.isEmpty ?? true) return 'Please describe the issue';
                  if ((value?.length ?? 0) < 10) return 'Description must be at least 10 characters';
                  return null;
                },
              ),
              const SizedBox(height: 24),
              
              const Text('Attach Photo (Simulated)', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Container(
                height: 120,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(12),
                  color: Colors.grey.shade50,
                ),
                child: const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.add_a_photo, size: 40, color: Colors.grey),
                    SizedBox(height: 8),
                    Text(
                      'Photo simulation enabled\n(No camera access in DartPad)',
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 32),
              
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  onPressed: _isSubmitting ? null : () {
                    if (_formKey.currentState!.validate()) {
                      setState(() => _isSubmitting = true);
                      Future.delayed(const Duration(seconds: 1), () {
                        widget.onSubmit(
                          _locationController.text,
                          _selectedIssueType,
                          _descriptionController.text,
                        );
                        if (mounted) setState(() => _isSubmitting = false);
                      });
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2E7D32),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: _isSubmitting
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2, 
                          valueColor: AlwaysStoppedAnimation(Colors.white)
                        ),
                      )
                    : const Text(
                        "SUBMIT REPORT", 
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)
                      ),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                '✓ Simulated submission\n✓ Auto-status updates\n✓ No plugins required',
                textAlign: TextAlign.center, 
                style: TextStyle(color: Colors.green, fontSize: 12)
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MapView extends StatefulWidget {
  final List<BinSensor> bins;

  const MapView({super.key, required this.bins});

  @override
  State<MapView> createState() => _MapViewState();
}

class _MapViewState extends State<MapView> {
  late final MapController _mapController = MapController();
  late Truck _truck;
  List<LatLng> _truckPath = [];

  List<LatLng> _route = [
  LatLng(14.6405, 121.0745),
  LatLng(14.6410, 121.0748),
  LatLng(14.6420, 121.0750),
  LatLng(14.6430, 121.0752),
  LatLng(14.6440, 121.0755),
  LatLng(14.6450, 121.0758),
  LatLng(14.6460, 121.0760),
];

int _routeIndex = 0;

void _updateTruckFromArduino() {
  Timer.periodic(const Duration(seconds: 2), (_) {
    setState(() {
      // 🔁 LOOP CHECK FIRST (SAFE)
      if (_routeIndex >= _route.length) {
        _routeIndex = 0;
        _truckPath.clear(); // optional
      }

      _truck.lat = _route[_routeIndex].latitude;
      _truck.lng = _route[_routeIndex].longitude;

      _truckPath.add(_route[_routeIndex]);

      // 🚛 FOLLOW CAMERA
      _mapController.move(
        LatLng(_truck.lat, _truck.lng),
        _mapController.camera.zoom,
      );

      _routeIndex++;
    });
  });
}

  @override
  void initState() {
    super.initState();

    // ✅ Initialize truck
    _truck = Truck(lat: 14.6405, lng: 121.0745);

    // ✅ Call the function
    _updateTruckFromArduino();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Live Map Tracking")),
      body: FlutterMap(
        mapController: _mapController,
        options: MapOptions(
  initialCenter: LatLng(14.6405, 121.0745),
  initialZoom: 16,

  // ✅ ADD THESE
  interactionOptions: const InteractionOptions(
    flags: InteractiveFlag.all, // allow all gestures
  ),
),
        children: [
          TileLayer(
            urlTemplate: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
            userAgentPackageName: 'com.example.wastewatch',
          ),
          
          PolylineLayer(
  polylines: [
    Polyline(
  points: _route,
  strokeWidth: 5,
  color: Colors.blue,
),
  ],
),

MarkerLayer(
  markers: [
    // 🗑️ BIN MARKERS
    ...widget.bins.map((bin) => Marker(
          point: LatLng(bin.lat, bin.lng),
          width: 80,
          height: 80,
          child: GestureDetector(
            onTap: () {
              print("Bin: ${bin.location}");
            },
            child: Column(
              children: [
                Icon(
                  Icons.delete,
                  color: bin.statusColor,
                  size: 32,
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    "${(bin.fillLevel * 100).toInt()}%",
                    style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        )),

    // 🚛 TRUCK MARKER
    Marker(
      point: LatLng(_truck.lat, _truck.lng),
      width: 70,
      height: 70,
      child: Column(
        children: const [
          Icon(
            Icons.local_shipping,
            color: Colors.blue,
            size: 36,
          ),
          Text(
            "Truck",
            style: TextStyle(fontSize: 10),
          ),
        ],
      ),
    ),
  ],
),
        ],
      ),
    );
  }
}